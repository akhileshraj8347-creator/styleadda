import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(
      const MaterialApp(debugShowCheckedModeBanner: false, home: StyleAdda()));
}

class StyleAdda extends StatefulWidget {
  const StyleAdda({super.key});
  @override
  State<StyleAdda> createState() => _S();
}

class _S extends State<StyleAdda> {
  String upiId = "9125310266@fam";
  String whatsapp = "919125310266";
  String adminPass = "Akhil9125#";
  bool login = false;
  String uName = "", uMobile = "", uAdd = "", uEmail = "";
  String search = "";
  String selCat = "All";
  List<Map<String, dynamic>> cart = [];

  List<Map<String, dynamic>> all = [
    {
      "name": "Winter Sweater",
      "cat": "Winter",
      "price": 799,
      "img":
          "https://images.unsplash.com/photo-1576871337622-98d48d1cf531?w=500"
    },
    {
      "name": "Winter Jacket",
      "cat": "Winter",
      "price": 1299,
      "img": "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=500"
    },
    {
      "name": "Mens Shirt",
      "cat": "Shirt",
      "price": 599,
      "img":
          "https://images.unsplash.com/photo-1603252109303-2751441dd157?w=500"
    },
    {
      "name": "Jeans",
      "cat": "Jeans",
      "price": 999,
      "img": "https://images.unsplash.com/photo-1542272604-787c3835535d?w=500"
    },
    {
      "name": "Plazo Set",
      "cat": "Plazo",
      "price": 699,
      "img":
          "https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?w=500"
    },
  ];

  List<Map<String, dynamic>> get filtered {
    List<Map<String, dynamic>> list = [];
    for (var e in all) {
      bool c = selCat == "All" || e["cat"] == selCat;
      bool s = search.isEmpty ||
          e["name"].toString().toLowerCase().contains(search.toLowerCase());
      if (c && s) {
        list.add(e);
      }
    }
    return list;
  }

  int get total {
    int t = 0;
    for (var e in cart) {
      t = t + (e["price"] as int);
    }
    return t;
  }

  Future<void> sendOrder() async {
    String msg =
        "NAYA ORDER - StyleAdda\nNaam: $uName\nMobile: $uMobile\nAddress: $uAdd\nEmail: $uEmail\n";
    for (int i = 0; i < cart.length; i++) {
      msg = msg + "${i + 1}. ${cart[i]["name"]} - Rs.${cart[i]["price"]}\n";
    }
    msg = msg + "Total: Rs.$total\nPayment FamPay se ho gaya - $upiId";
    Uri uri =
        Uri.parse("https://wa.me/$whatsapp?text=${Uri.encodeComponent(msg)}");
    await launchUrl(uri, mode: LaunchMode.externalApplication);
    setState(() {
      cart.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!login) {
      return loginPage();
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text("StyleAdda"),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
              icon: const Icon(Icons.admin_panel_settings),
              onPressed: openAdmin),
          IconButton(
              icon: const Icon(Icons.shopping_cart), onPressed: openCart),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: TextField(
              onChanged: (v) {
                setState(() {
                  search = v;
                });
              },
              decoration: InputDecoration(
                  hintText: "Search shirt, jeans...",
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30))),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: ["All", "Winter", "Shirt", "Jeans", "Plazo"].map((c) {
              return Padding(
                padding: const EdgeInsets.all(4),
                child: ChoiceChip(
                    label: Text(c),
                    selected: selCat == c,
                    onSelected: (v) {
                      setState(() {
                        selCat = c;
                      });
                    }),
              );
            }).toList(),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(10),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.7,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10),
              itemCount: filtered.length,
              itemBuilder: (ctx, i) {
                var it = filtered[i];
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      cart.add(it);
                    });
                    openCart();
                  },
                  child: Card(
                    child: Column(
                      children: [
                        Expanded(
                            child: Image.network(it["img"],
                                width: double.infinity, fit: BoxFit.cover)),
                        Padding(
                          padding: const EdgeInsets.all(8),
                          child: Text("${it["name"]} - Rs.${it["price"]}",
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget loginPage() {
    TextEditingController n = TextEditingController();
    TextEditingController m = TextEditingController();
    TextEditingController a = TextEditingController();
    TextEditingController e = TextEditingController();
    return Scaffold(
      backgroundColor: Colors.deepPurple,
      body: Center(
        child: Card(
          margin: const EdgeInsets.all(20),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text("StyleAdda",
                    style:
                        TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                const SizedBox(height: 15),
                TextField(
                    controller: n,
                    decoration: const InputDecoration(
                        labelText: "Naam", border: OutlineInputBorder())),
                const SizedBox(height: 10),
                TextField(
                    controller: m,
                    decoration: const InputDecoration(
                        labelText: "Mobile", border: OutlineInputBorder())),
                const SizedBox(height: 10),
                TextField(
                    controller: a,
                    decoration: const InputDecoration(
                        labelText: "Address", border: OutlineInputBorder())),
                const SizedBox(height: 10),
                TextField(
                    controller: e,
                    decoration: const InputDecoration(
                        labelText: "Email", border: OutlineInputBorder())),
                const SizedBox(height: 15),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepPurple,
                      foregroundColor: Colors.white),
                  onPressed: () {
                    setState(() {
                      uName = n.text;
                      uMobile = m.text;
                      uAdd = a.text;
                      uEmail = e.text;
                      login = true;
                    });
                  },
                  child: const Text("SHOPPING SHURU KARO"),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void openCart() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text("Tera Cart aur Payment",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              for (var e in cart) Text("${e["name"]} - Rs.${e["price"]}"),
              const SizedBox(height: 10),
              Text("Total: Rs.$total",
                  style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.deepPurple)),
              const SizedBox(height: 10),
              const Text("QR Scan Karke Payment Karo"),
              const SizedBox(height: 8),
              Image.network(
                  "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${Uri.encodeComponent("upi://pay?pa=$upiId&pn=StyleAdda&cu=INR")}",
                  height: 180,
                  width: 180),
              Text("UPI: $upiId"),
              const SizedBox(height: 15),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white),
                onPressed: () {
                  Navigator.pop(ctx);
                  sendOrder();
                },
                child: const Text("PAYMENT HO GAYA - ORDER KARO"),
              ),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  void openAdmin() {
    TextEditingController p = TextEditingController();
    showDialog(
      context: context,
      builder: (c) {
        return AlertDialog(
          title: const Text("Admin Login"),
          content: TextField(
              controller: p,
              obscureText: true,
              decoration: const InputDecoration(labelText: "Password")),
          actions: [
            TextButton(
                onPressed: () {
                  Navigator.pop(c);
                },
                child: const Text("Cancel")),
            ElevatedButton(
              onPressed: () {
                if (p.text == adminPass) {
                  Navigator.pop(c);
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("Admin Khul Gaya")));
                }
              },
              child: const Text("Login"),
            ),
          ],
        );
      },
    );
  }
}
